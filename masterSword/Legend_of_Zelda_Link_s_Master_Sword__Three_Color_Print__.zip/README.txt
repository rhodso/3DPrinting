                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1465539
Legend of Zelda: Link's Master Sword! Three Color Print!  by 3DCentralVA is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Seriously though, is there anything cooler than Link's Master Sword?

Print this one in three colors, in just a few easy pieces! Print the hilt with support, so it can print upright! Use [super glue](https://amzn.to/2qJDP54) to give the blade and handle a really snug fit!

Available for purchase via Etsy: http://etsy.me/201vbZF

SILVER/GREY
blade_1.stl
blade_2.stl
blade_3.stl
blade_4.stl

BLUE
hilt.stl
handle.stl

GOLD
gem.stl x 2
hilt_bit.stl x 1

# Print Settings

Rafts: Yes
Supports: Yes

Notes: 
Print 6x blade_pin.stl and use them to securely connect the blade parts together!